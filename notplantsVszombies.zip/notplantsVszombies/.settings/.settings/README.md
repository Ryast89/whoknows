# notplantsVszombies
this isn't plants vs zombies


-Plants V Zombies defense?
  -‘Lanes” that you can place defenders in
  -Defenders have health
  -Zombies or other enemies go down the lanes and try to reach end
  -If they reach defenders, attack them
  -Defenders attack zombies in different ways
Plants: 
  -multiple lane shooter
  -Money collector
  -Multiple lane shooter/AOE? (catapult)
