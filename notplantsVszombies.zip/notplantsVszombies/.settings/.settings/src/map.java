
public class map {
public byte[][] pixels = new byte[600][600];

public map(int level) {
	switch(level) {
		case 1: 
			platform(30, 0, 600);
			platform(25, 150,150);
			platform(21, 150,200);
			platform(17, 150,250);
			platform(13, 150,300);
			platform(9, 150,350);
			platform(6, 0, 50);
			platform(6, 100, 100);
			platform(6, 450, 50);
			platform(6, 550, 50);
			//spike(12,500,100);
			//spike(12,0,100);
			exit(29, 550, 50);
		
			break;
			
		
	}

	
}

	private void platform(int height, int indent, int length) {
		for(int j = 0; j < 20; j++) {
			for(int i = 0; i < length; i++) {
				pixels[indent + i][((height*20) - 1) - j] = 1;
			}
		}
	}
	private void exit(int height, int indent, int size) {
		for(int j = 0; j < 20; j++) {
			for(int i = 0; i < size; i++) {
				pixels[indent + i][((height*20) - 1) - j] = 3;
			}
		}
	}
	private void spike(int height, int indent, int length) {
		for(int j = 0; j < 20; j++) {
			for(int i = 0; i < length; i++) {
				pixels[indent + i][((height*20)) - j] = 2;
			}
		}
	}
	
}
